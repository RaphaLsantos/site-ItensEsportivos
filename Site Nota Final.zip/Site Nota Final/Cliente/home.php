<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="homee.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Home</title>
</head>
<body>
<header>
        <div class="logo"><img src="../img/logo/logo3.png" width="120px" height="60px" alt=""></div>
        <input type="checkbox" id="nav_check" hidden>
        <nav class="nav-items">
            <ul>
                <li>
                    <a href="home.php" class="active">Home</a>
                </li>
                <li>
                    <a href="galeria.php" class="opcoes">Galeria</a>
                </li>
                <li>
                    <a href="consultaDepoimento.php" class="opcoes" >Depoimentos</a>
                </li>
                <li>
                    <a href="#ctt" class="opcoes" >Contato</a>
                </li>
                <li>
                    <a href="../area-restrita/login.php" class="opcoes" >Login</a>
                </li>

  <script src="../Bootstrap5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
                        </form>
                        </div>
                        </div>

        </nav>
        

        <label for="nav_check" class="items">
            <div></div>
            <div></div>
            <div></div>
        </label>
    </header>


<main class="main">
        <section class="home">
            
        <div class="home-logo">
                <img class="img-logo" src="../img/home/carro.jpg" width="400px" height="200px" alt="logo-empresa">
            </div>

            <div class="home-text">
                <h4 class="text-h4">BuyCars.</h4>
                <h1 class="text-h1">Melhor lugar para carros Esportivos!</h1>
                <p class="text-p">Venha sentir o que é a velocidade...</p>
            </div>
        </section>
    </main>

    <img class="banner1" src="../img/home/gif.gif" alt=""><br><br><br>

    <h1 class="destaque">Destaques da Loja no ano de 2023!</h1><br>


    <main class="main-card">
        <section class="home-card">  
        <div class="card">  
            </div>
            <img src="../img/home/encontro.jpg" height="180px" width="220px" class="card-img-1" alt = "">
            <div class="text-card">
                <h1 class="text-h1">Encontros de Carros esportivos</h1>
                <p class="text-p">Aqui você se senti muito mais feliz!</p>
               
                <div class="w3-container">
                <button onclick="document.getElementById('id01').style.display='block'" class="w3-button w3-black">Saiba mais!</button>

                <div id="id01" class="w3-modal">
                    <div class="w3-modal-content w3-animate-top w3-card-4">
                    <header class="w3-container w3-teal"> 
                        <span onclick="document.getElementById('id01').style.display='none'" 
                        class="w3-button-x w3-display-topright">&times;</span>
                        <h2 class="h1-modal">Encontro Esportivo</h2>
                    </header>
                    <div class="w3-container">
                        <p class="p-modal">Para participar desse evento você deve ter pelo menos um automóvel adquirido em nossa loja</p>
                        <p class="p-modal">Assim que obter um veículo em nossa loja, automáticamente você receberá um convite para o grande evento</p>
                    </div>
                    <footer class="w3-container-footer w3-teal">
                        <a type="submit" value="Compre seu carro" class="button" href="galeria.php">Compre seu carro</a>
                    </footer>
                    </div>
                </div>
                </div>
            </div>
        </section>

        <section class="home-card">  
        <div class="card">  
            </div>
            <img src="../img/home/R34.jpg" height="180px" width="220px" class="card-img-1" alt = "">
            <div class="text-card">
                <h1 class="text-h1">Novidade em nossa loja!<br>A máquina de verdade chegou</h1>
                <p class="text-p">Skyline r34, o mais potente do mundo esportivo</p>
                <a href="galeria.php" class="button-card" type="submit" value="Saiba mais">Compre aqui</a>
            </div>
        </section>


        <section class="home-card">  
        <div class="card">  
            </div>
            <img src="../img/home/Supra.jpg" height="180px" width="220px" class="card-img-1" alt = "">
            <div class="text-card">
                <h1 class="text-h1">Conheça nosso querido Supra<br> velocidade é aqui</h1>
                <p class="text-p">Quer sentir o que é nostálgia?</p>
                <a href="galeria.php" class="button-card" type="submit" value="Saiba mais">Compre aqui</a>
            </div>
        </section>
    </main>


<div id="ctt">
<footer class="footer">

<div class="left">

    <h4 class="title-footer">Buy<span>Cars</span></h4>

    <p class="links">
              
      <a href="file:///E:/ETEC/PW1/AULA%2010/SITE%20loja/ctt.index.html" title="Home">CONTATO</a>
  </p>

            <p class="Copyright">Copyright &copy; 2023 Seu site - Todos os Direitos Reservados. <br>Melhor loja auto-esportiva do Brasil, <br>nosso cliente pode ter a total confiança em nós, <br>seremos eternamente agradecidos..</p>


</div>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Contato</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="../area-restrita/Email/salvar.php" method="post">
        <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label" >Nome</label>
        <input name="nome" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"	required>
      </div>
          <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label" >Email</label>
        <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"	required>
      </div>
      <div class="col mb-3">
                  <label for="recipient-name" class="col-form-label">Assunto:</label>
                  <select class="form-select" name="assunto">
                    <option value="Documento não validado">Documento não validado</option>
                    <option value="Veículo em péssimas condições">Veículo em péssimas condições</option>
                    <option value="Falta de peça">Falta de peça</option>
                    <option value="Entrega fora do prazo">Entrega fora do prazo</option>
                  </select>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
        <button type="submit" class="btn btn-primary">Enviar</button>
      </div>
    </form>
      </div>
     
    </div>
  </div>
</div>

<form action="../area-restrita/Email/salvar.php" method="post">
        <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label" >Nome</label>
        <input name="nome" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"	required>
      </div>
          <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label" >Email</label>
        <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"	required>
      </div>
      <div class="col mb-3">
                  <label for="recipient-name" class="col-form-label">Assunto:</label>
                  <select class="form-select" name="assunto">
                    <option value="Documento não validado">Documento não validado</option>
                    <option value="Veículo em péssimas condições">Veículo em péssimas condições</option>
                    <option value="Falta de peça">Falta de peça</option>
                    <option value="Entrega fora do prazo">Entrega fora do prazo</option>
                  </select>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
        <button type="submit" class="btn btn-primary">Enviar</button>
      </div>
    </form>

</footer>
</div>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</html>